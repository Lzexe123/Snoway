module.exports = {
    private: "1188962621504888862",
    snoway: {
        panel: "http://167.114.48.55:30126/api",
        api: "eHNdapE343dET5GY5ktc978ABhg4w3suD5Ny4sEW4F5KLg8u84"
    },
    manager: {
        panel: "http://167.114.48.54:3000/api",
        key: "bXx66w2zR8z5RPdOk9R3"
    },
    api: {
        giphy: {
            token: "7fnSedoAHUMTnlH7nHUYtr7RhQDaAXw5"
        }
    }
}