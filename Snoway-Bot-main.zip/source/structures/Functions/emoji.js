module.exports = {
    buyers: "<:buyer:1189236174045323285>",
    owners: "<:owners:1189298926851993676>",
    del: "<:delete:1203418392225390672>",
    
    // Captcha 

    param: "<:settings:1202977729969131600>",
    new: "<:new:1203415887697158164>",
    temps: "<:temps:1197834074975387658>",
    age: "<:age:1202977707739062332>",
    users: "<:user:1202977739229892651>",
    channel: "<:channel:1202977817004875847>",
    retour: "<:retour:1202977490423775303>",
    valide: "<:valide:1202977818942767176>",
    no: "<:nop:1202977817894199356>",
    danger: "<:danger:1203299194840944650>",

    // Leaderboard 

    vocal: "<:vocal:1210808528319815740>",
    message: "<:message:1210808484254326854>",

    // PANEL
    status_off: "<:status_off:1217192735807635546>",
    status_on: "<:status_on:1217192730690846851>",
    power_on: "<:power_on:1217060775005524038>",
    power_off: "<:power_off:1217060748136812554",
    sanction_on: "<:sanction_on:1217079403008360468",
    sanction_off: "<:sanction_off:1217079404388421652>",
    user_on: "<:user_on:1217171351014604922>",
    user: "<:user:1217575410242556027>",
    user_off: "<:user_off:1217171349471105165>",
    role_on: "<:role_on:1217171347793510412>",
    role: "<:role:1217575728871116841>",
    role_off: "<:role_off:1217171346262327406>",
    wl_on: "<:wl_on:1217173485374148679>",
    wl_off: "<:wl_off:1217173484137091152>",
    logs: "<:logs:1217484515543355423>",
    no_white: "<:snoway_no:1217570485433274431>",
    slash: "<:slash_cmd:1218216636356628510>",
    temps: "<:temps:1218218228350980098>",
    message: "<:message:1218232422210998442>"
}