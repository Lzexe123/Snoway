module.exports = {
  token: "MTMwMjI1NzgwNDg4MjQ4MTE3Mw.G-He0E.LvL_uwS3zqq3MppO0MOcxFRY1pIFBSrNmoIkM4",
  botId: "1302257804882481173",
  buyers: ["1261303926309781595"],
  prefix: "+",
  color: "#2b2d31",
};